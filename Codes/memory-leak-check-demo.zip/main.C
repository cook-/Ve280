#include <iostream>
using namespace std;

int main(int argc, char *argv[])
{
    int *ip = new int(5);
    cout << *ip << endl;
    //delete ip;

    return 0;
}
