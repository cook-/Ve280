#ifndef FUNC_H
#define FUNC_H

// Function Declaration
int mult(int a, int b);
int factorial(int n);

#endif
