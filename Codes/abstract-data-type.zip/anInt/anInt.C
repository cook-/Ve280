#include "anInt.h"

int anInt::get_value()
{
    return v;
}

void anInt::set_value(int newValue) 
{
    v = newValue;
}

