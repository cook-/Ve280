#ifndef SAY_HELLO_H
#define SAY_HELLO_H

void say_hello();

#endif
