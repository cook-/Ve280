#include <iostream>
#include "say_hello.h"

using namespace std;

void say_hello()
{
	cout << "Hello world!" << endl;
}
